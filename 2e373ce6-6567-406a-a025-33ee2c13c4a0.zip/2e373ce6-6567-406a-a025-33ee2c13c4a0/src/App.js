import React, { Component } from "react";
import Filter from "./components/Filter";
import RecordTable from "./components/RecordTable";

class App extends Component {
  constructor() {
    super();
    this.state = { sortingType: "None" };
  }

  changeSortingType = () => {
    console.log(this.sortingType);
    this.setState({
      sortingType: "None"
    });
  };

  render() {
    return (
      <div className="container-fluid">
        <center>
          <h1>Birthday Records</h1>
        </center>
        <Filter changeSortType={this.changeSortingType}></Filter>
        <RecordTable checkSortingType={this.state.sortingType}></RecordTable>
      </div>
    );
  }
}

export default App;
